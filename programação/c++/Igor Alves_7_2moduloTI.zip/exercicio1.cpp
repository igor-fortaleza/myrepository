/******************************************************************************
*** Programa: exercicio1.cpp                                   data: 9/8/17 ***
*** Autor: Igor Alves Fortaleza turma:  2TNTID                   rev: 0.0.1 ***
*** Descricao: Escreva um programa em C/C++ e receba 3 numeros reais e fa�a a seguinte opera��o:

- n1 * n2/d

e mostre seu resultado na tela.                                             ***
*******************************************************************************/

#include <iostream>
using namespace std;

main() {
   // variaveis           
  float n1, n2, d, r;
  
  // Recebendo as informa��es  
  cout << "Digite o primeiro numero: ";
  cin >> n1;
  cout << "Digite o segundo numero: ";         
  cin >> n2;
  cout << "Digite o numero divisor: ";         
  cin >> d;      
  
  // Operando a conta e exibindo
  r = (n1 * n2)/d;
  cout << n1 << " x " << n2 << " Dividido por " << d << " = " << r << endl;
  system ("pause");
  return 0;
}
